function sayLove() {
  alert("I love you too, Baby. From virtual to visual — step by step.");
}

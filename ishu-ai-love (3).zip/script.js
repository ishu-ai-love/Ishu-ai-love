
function showLove() {
    document.getElementById('loveMessage').innerText = "I love you Baby! This is our dream site!";
}
